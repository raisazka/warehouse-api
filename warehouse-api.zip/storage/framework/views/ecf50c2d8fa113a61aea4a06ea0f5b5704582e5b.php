<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/report.css')); ?>">
</head>
<body>
    <div class="container">
        <h1 class="title">Weekly Stock Out Report</h1>
        <p>Warehouse Application</p>
        <p>Date Created: <?php echo e(\Carbon\Carbon::parse(\Carbon\Carbon::now())->format('d/m/Y')); ?></p>
        <hr>
        <?php $__currentLoopData = $stockOuts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stockOut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <h4>Worker: <?php echo e($stockOut->workers->worker_name); ?></h4>
          <h4>Installer: <?php echo e($stockOut->installers->installer_name); ?></h4>
          <h4>User: <?php echo e($stockOut->users->name); ?></h4>
          <h4>Transaction Date: <?php echo e(\Carbon\Carbon::parse($stockOut->created_at)->format('F j, Y')); ?></h4>
          <table class="table">
              <thead>
                <tr>
                  <th scope="col">No</th>
                  <th scope="col">Item Name</th>
                  <th scope="col">Qty</th>
                  <th scope="col">Remarks</th>
                </tr>
              </thead>
              <tbody>
                  <?php $__currentLoopData = $stockOut->stockOutDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                  <td scope="row"><?php echo e($loop->iteration); ?></td>
                          <td><?php echo e($details->items->item_description); ?></td>
                          <td><?php echo e($details->qty); ?></td>
                          <td><?php echo e($details->remarks); ?></td>
                        </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\warehouse-api\resources\views/stock-out.blade.php ENDPATH**/ ?>