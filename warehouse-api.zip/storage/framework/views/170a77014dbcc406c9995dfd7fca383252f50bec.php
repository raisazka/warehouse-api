<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/report.css')); ?>">
</head>
<body>
    <div class="container">
        <h1 class="title">Weekly Stock In Report</h1>
        <p>Warehouse Application</p>
        <p>Date Created: <?php echo e(\Carbon\Carbon::parse(\Carbon\Carbon::now())->format('d/m/Y')); ?></p>
        <hr>
        <table class="table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">User</th>
                <th scope="col">Item Name</th>
                <th scope="col">Qty</th>
                <th scope="col">Remarks</th>
                <th scope="col">Stock In Date</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $stockIns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stockIn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td scope="row"><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($stockIn->users->name); ?></td>
                        <td><?php echo e($stockIn->items->item_description); ?></td>
                        <td><?php echo e($stockIn->qty); ?></td>
                        <td><?php echo e($stockIn->remarks); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($stockIn->created_at)->format('F j, Y')); ?></td>
                      </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\warehouse-api\resources\views/stock-in.blade.php ENDPATH**/ ?>